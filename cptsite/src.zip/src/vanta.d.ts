declare module 'vanta/dist/vanta.net.min' {
  const VANTA: any;
  export default VANTA;
}