export { default as dark } from './dark.svg'; 
export { default as facebook } from './facebook.svg'; 
export { default as github } from './github.svg'; 
export { default as google } from './google.svg'; 
export { default as main } from './main.svg'; 
export { default as vimeo } from './vimeo.svg'; 
export { default as x } from './x.svg'; 
