import React from 'react';

export const AboutUsPage = () => {
    return (
        <div className="about-us-container">
            <header className="about-us-header">
                <h1>About Us</h1>
            </header>
            <section className="about-us-content">
                <p>
                    Welcome to the official page of our Competitive Programming Team! We are a group of passionate problem solvers and coding enthusiasts dedicated to pushing the boundaries of algorithmic thinking and software development.
                </p>
                <p>
                    Our mission is to foster a collaborative environment where members can learn, grow, and excel in the field of competitive programming. Through regular practice sessions, contests, and knowledge-sharing, we aim to build a community that thrives on innovation and teamwork.
                </p>
                <p>
                    Whether you're a seasoned coder or just starting your journey, our team is here to support and challenge you. Join us as we tackle complex problems, compete in global contests, and strive for excellence in the world of programming.
                </p>
            </section>
            <footer className="about-us-footer">
                <p>Contact us: team@competitiveprogramming.com</p>
            </footer>
        </div>
    );
};

export default AboutUsPage;